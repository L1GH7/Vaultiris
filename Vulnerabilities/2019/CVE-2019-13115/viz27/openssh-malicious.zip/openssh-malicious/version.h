/* $OpenBSD: version.h,v 1.85 2019/10/09 00:04:57 djm Exp $ */

#define SSH_VERSION	"OpenSSH_8.1"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
