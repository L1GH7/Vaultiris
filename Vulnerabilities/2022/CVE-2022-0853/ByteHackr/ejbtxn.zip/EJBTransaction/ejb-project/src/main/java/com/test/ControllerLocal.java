package com.test;

import javax.ejb.Local;

@Local
public interface ControllerLocal {
	public void mainCall();
}
